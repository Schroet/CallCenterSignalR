﻿namespace CallCenter.Models
{
    public enum OperatorTitle
    {
        Operator = 0x0,
        Manager = 0x1,
        SeniorManager = 0x2
    }
}
