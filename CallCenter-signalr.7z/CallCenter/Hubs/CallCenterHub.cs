﻿using CallCenter.Models;
using CallCenter.Services;
using Microsoft.AspNetCore.SignalR;

namespace CallCenter.Hubs
{
    public interface ICallCenterClient
    {
        void AppendLine(string message);
    }

    public class CallCenterHub : Hub<ICallCenterClient>
    {
        private readonly ICallCenter _callCenter;
        public CallCenterHub(ICallCenter callCenter)
        {
            _callCenter = callCenter;
        }

        public void Start(SimulationOptions options)
        {
            if (!_callCenter.IsRunning)
            {
                _callCenter.Start(options);
            }   
        }

        public void Pause()
        {

        }

        public void Stop()
        {
            if (_callCenter.IsRunning)
            {
                _callCenter.Stop();
            }
        }

        public void SendCall()
        {
            if (_callCenter.IsRunning)
            {
                _callCenter.SendCall();
            }
        }

    }
}
